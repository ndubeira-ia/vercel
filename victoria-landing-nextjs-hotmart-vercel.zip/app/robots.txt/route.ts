export async function GET() {
  return new Response(
`User-agent: *
Allow: /
Sitemap: https://victoriadegratitud.com.ar/sitemap.xml`,
    { headers: { 'Content-Type': 'text/plain' } }
  )
}
