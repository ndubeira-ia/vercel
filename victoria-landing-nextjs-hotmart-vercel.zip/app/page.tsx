export default function Page() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-30 backdrop-blur bg-white/70 border-b border-neutral-200">
        <div className="container py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full" style={{backgroundImage:'linear-gradient(135deg,#6A4C93,#D4AF37)'}}/>
            <span className="font-serif text-xl">Victoria de Gratitud</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#packs" className="hover:text-brandViolet">Packs</a>
            <a href="#beneficios" className="hover:text-brandViolet">Beneficios</a>
            <a href="#testimonios" className="hover:text-brandViolet">Testimonios</a>
            <a href="#faq" className="hover:text-brandViolet">FAQ</a>
          </nav>
          <a href="#precios" className="btn-ghost">Empezar</a>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 opacity-90" style={{backgroundImage:'linear-gradient(135deg,#6A4C93,#D4AF37)'}} />
        <div className="container py-20 sm:py-28 text-white">
          <div className="max-w-3xl">
            <h1 className="font-serif text-4xl sm:text-6xl leading-tight drop-shadow">Eleva tu energía. Ordena tu mente. Diseña tu vida.</h1>
            <p className="mt-5 text-lg/relaxed text-white/90">Tres caminos simples para empezar hoy: diarios y hábitos, meditaciones guiadas y mentoría con seguimiento.</p>
            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <a href="#precios" className="btn-primary">Quiero empezar ahora</a>
              <a href="#lead" className="btn-ghost">Probar gratis</a>
            </div>
            <div className="mt-6 text-sm text-white/80">⭐⭐⭐⭐⭐ 1.200+ descargas · 95% satisfacción</div>
          </div>
        </div>
      </section>

      {/* Beneficios */}
      <section id="beneficios" className="container py-16">
        <h2 className="font-serif text-3xl">Beneficios clave</h2>
        <p className="text-neutral-600 mt-2">Diseñado para claridad, calma y constancia — con resultados en días, no meses.</p>
        <div className="mt-8 grid sm:grid-cols-3 gap-6">
          {[
            {title:'Claridad',desc:'Convierte ruido mental en foco diario con plantillas simples.'},
            {title:'Calma',desc:'Regula emociones con meditaciones y breathwork en minutos.'},
            {title:'Constancia',desc:'Plan de 30 días + seguimiento para sostener el cambio.'},
          ].map((b,i)=>(
            <div key={i} className="card">
              <div className="h-10 w-10 rounded-lg mb-4" style={{backgroundImage:'linear-gradient(135deg,#6A4C93,#D4AF37)'}} />
              <h3 className="text-xl font-semibold">{b.title}</h3>
              <p className="mt-2 text-sm text-neutral-600">{b.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Packs */}
      <section id="packs" className="border-y bg-neutral-50/60">
        <div className="container py-16">
          <div className="flex items-end justify-between gap-6">
            <div>
              <h2 className="font-serif text-3xl">Elige tu punto de partida</h2>
              <p className="text-neutral-600 mt-2">Tres ofertas simples. Elige la que mejor se adapte a tu momento.</p>
            </div>
            <a href="#comparativa" className="text-sm underline decoration-brandViolet/50 underline-offset-4">Ver comparativa</a>
          </div>

          <div className="mt-10 grid md:grid-cols-3 gap-6">
            {/* Pack 1 */}
            <div className="card hover:shadow-md transition">
              <div className="mb-2 text-xs uppercase tracking-wider text-neutral-500">Entrada</div>
              <h3 className="text-2xl font-semibold">Diarios & Infoproductos</h3>
              <p className="mt-2 text-sm text-neutral-600">Hábitos cuánticos + Gratitud + Nexo. Plantillas y plan 30 días.</p>
              <ul className="mt-4 space-y-2 text-sm">
                <li>✓ Diario de Gratitud (PDF + editable)</li>
                <li>✓ Diario Nexo + guía de uso</li>
                <li>✓ Mini‑ebook Hábitos + plantillas</li>
                <li>✓ 20 afirmaciones + 10 plantillas semanales</li>
              </ul>
              <div className="mt-6">
                <div className="text-3xl font-bold">$</div>
                <div className="text-xs text-neutral-500">Acceso de por vida · Descarga inmediata</div>
              </div>
              <div className="mt-6 flex flex-col gap-3">
                <a href="https://pay.hotmart.com/XXXXX" className="btn-primary">Comprar ahora</a>
                <button className="btn-ghost">Ver todo lo que incluye</button>
              </div>
            </div>

            {/* Pack 2 */}
            <div className="relative card border-2 border-brandViolet shadow-lg ring-1 ring-brandViolet/10">
              <div className="absolute -top-3 right-6 badge-reco">Recomendado</div>
              <div className="mb-2 text-xs uppercase tracking-wider text-neutral-500">Core</div>
              <h3 className="text-2xl font-semibold">Meditaciones con Victoria</h3>
              <p className="mt-2 text-sm text-neutral-600">6 meditaciones + 2 breathwork + calendario de práctica 14 días.</p>
              <ul className="mt-4 space-y-2 text-sm">
                <li>✓ Mañana, Foco, Autocompasión, Abundancia, Limpieza emocional, Sueño</li>
                <li>✓ 2 Breathwork básicos (5–7 min)</li>
                <li>✓ Playlist y fondo de intención</li>
                <li>✓ Audio SOS 3’ para ansiedad</li>
              </ul>
              <div className="mt-6">
                <div className="text-3xl font-bold">$$</div>
                <div className="text-xs text-neutral-500">Mayor valor · Resultados en 2 semanas</div>
              </div>
              <div className="mt-6 flex flex-col gap-3">
                <a href="https://pay.hotmart.com/YYYYY" className="btn-primary">Empezar con meditaciones</a>
                <button className="btn-ghost">Ver todo lo que incluye</button>
              </div>
            </div>

            {/* Pack 3 */}
            <div className="card hover:shadow-md transition">
              <div className="mb-2 text-xs uppercase tracking-wider text-neutral-500">Premium</div>
              <h3 className="text-2xl font-semibold">Mentoría & Seguimiento</h3>
              <p className="mt-2 text-sm text-neutral-600">Biblioteca + 1:1 (45–60min) + 2 semanas de chat.</p>
              <ul className="mt-4 space-y-2 text-sm">
                <li>✓ Plan personalizado y accountability</li>
                <li>✓ Auditoría de hábitos</li>
                <li>✓ Checklist de coherencia diaria</li>
                <li>✓ Bonus de upgrade limitado</li>
              </ul>
              <div className="mt-6">
                <div className="text-3xl font-bold">$$$</div>
                <div className="text-xs text-neutral-500">Cupos limitados · Soporte directo</div>
              </div>
              <div className="mt-6 flex flex-col gap-3">
                <a href="https://pay.hotmart.com/ZZZZZ" className="btn-primary">Agendar mi sesión 1:1</a>
                <button className="btn-ghost">Ver todo lo que incluye</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Comparativa */}
      <section id="comparativa" className="container py-16">
        <h2 className="font-serif text-3xl">Comparativa rápida</h2>
        <div className="mt-6 overflow-x-auto">
          <table className="min-w-[720px] w-full text-sm border-separate border-spacing-y-2">
            <thead>
              <tr className="text-left text-neutral-600">
                <th className="py-2 pr-4">Característica</th>
                <th className="py-2 px-4">Pack 1</th>
                <th className="py-2 px-4">Pack 2</th>
                <th className="py-2 px-4">Pack 3</th>
              </tr>
            </thead>
            <tbody>
              {[
                ['Plantillas y diarios', '✓', '—', '✓'],
                ['Meditaciones guiadas', '—', '✓', '✓ (selección)'],
                ['Plan 30 días', '✓', '✓', '✓ (personalizado)'],
                ['Sesión 1:1', '—', '—', '✓'],
                ['Seguimiento por chat', '—', '—', '✓ 2 semanas'],
                ['Garantía 7 días', '✓', '✓', '✓'],
              ].map((row,i)=> (
                <tr key={i} className="bg-neutral-50">
                  <td className="py-3 pr-4 font-medium">{row[0]}</td>
                  <td className="py-3 px-4">{row[1]}</td>
                  <td className="py-3 px-4">{row[2]}</td>
                  <td className="py-3 px-4">{row[3]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Testimonios */}
      <section id="testimonios" className="border-y bg-neutral-50/60">
        <div className="container py-16">
          <h2 className="font-serif text-3xl">Transformaciones reales</h2>
          <div className="mt-8 grid md:grid-cols-3 gap-6">
            {[
              {name:'María L.', text:'“Empecé por 5 minutos y en 2 semanas bajó mi ansiedad. El diario me ordenó el día.”'},
              {name:'Sofía R.', text:'“Las meditaciones de la mañana me cambiaron el foco. Duermo mejor y rindo más.”'},
              {name:'Nicolás U.', text:'“Con la mentoría armé un plan claro y lo sostuve. Por fin sentí progreso real.”'},
            ].map((t,i)=> (
              <div key={i} className="card">
                <div className="text-lg">{t.text}</div>
                <div className="mt-4 text-sm text-neutral-600">{t.name}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lead */}
      <section id="lead" className="container py-16">
        <div className="card bg-gradient-to-br from-white to-neutral-50">
          <div className="md:flex items-center justify-between gap-8">
            <div className="max-w-2xl">
              <h3 className="font-serif text-2xl">Tu primer paso en 5 minutos</h3>
              <p className="mt-2 text-neutral-700">Descarga el Starter Gratis: 1 meditación corta + 1 página de Diario de Gratitud + checklist 24h de coherencia.</p>
            </div>
            <form className="mt-6 md:mt-0 flex w-full max-w-md gap-2">
              <input type="email" placeholder="Tu email" className="flex-1 rounded-xl border px-4 py-3 outline-none focus:ring-2 focus:ring-brandViolet" />
              <button className="btn-primary">Descargar</button>
            </form>
          </div>
          <p className="mt-3 text-xs text-neutral-500">Al continuar aceptás la política de privacidad. Podés desuscribirte cuando quieras.</p>
        </div>
      </section>

      {/* Precios CTA */}
      <section id="precios" className="relative">
        <div className="container py-16">
          <div className="card text-center">
            <h2 className="font-serif text-3xl">Listo para empezar</h2>
            <p className="mt-2 text-neutral-600">Garantía 7 días · Pagos seguros · Acceso inmediato</p>
            <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
              <a href="https://pay.hotmart.com/YYYYY" className="btn-primary">Comprar Pack 2 (Recomendado)</a>
              <a href="#packs" className="btn-ghost">Ver otros packs</a>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t">
        <div className="container py-10 text-sm text-neutral-600">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div>
              <div className="font-serif text-lg">Victoria de Gratitud</div>
              <div className="mt-1 text-xs">Este material no reemplaza tratamiento médico/psicológico. Resultados varían.</div>
            </div>
            <div className="flex gap-6">
              <a href="#" className="hover:text-neutral-900">Privacidad</a>
              <a href="#" className="hover:text-neutral-900">Términos</a>
              <a href="#" className="hover:text-neutral-900">Contacto</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
