import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Victoria de Gratitud — Diarios, Meditaciones y Mentoría',
  description: 'Crea coherencia mente‑corazón con diarios, meditaciones y mentoría con seguimiento.'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  )
}
