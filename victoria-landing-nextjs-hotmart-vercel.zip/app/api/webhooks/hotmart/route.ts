import { NextRequest, NextResponse } from 'next/server'

// Simple signature check placeholder; adjust per Hotmart docs if you enable signatures.
function isTrusted(req: NextRequest) {
  // e.g., compare header 'x-hotmart-signature' with HMAC of body using SHARED_SECRET
  return true
}

export async function POST(req: NextRequest) {
  try {
    const raw = await req.text()
    // If Hotmart sends form-encoded, parse here; else JSON:
    let payload: any
    try { payload = JSON.parse(raw) } catch { payload = Object.fromEntries(new URLSearchParams(raw)) }

    if (!isTrusted(req)) {
      return NextResponse.json({ ok: false, error: 'untrusted' }, { status: 401 })
    }

    console.log('HOTMART EVENT:', payload)
    // TODO: persist to DB / call email/WhatsApp hooks

    return NextResponse.json({ ok: true })
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'error' }, { status: 500 })
  }
}
